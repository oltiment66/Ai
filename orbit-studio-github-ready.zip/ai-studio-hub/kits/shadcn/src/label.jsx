"use client";
import * as React from "react";
import { Label as LabelPrimitive } from "radix-ui";
import { cva } from "class-variance-authority";
import { cn } from "./utils.js";
const labelVariants = cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
);
const Label = React.forwardRef(({ className, ...props }, ref) => <LabelPrimitive.Root
  ref={ref}
  className={cn(labelVariants(), className)}
  {...props}
/>);
Label.displayName = LabelPrimitive.Root.displayName;
export {
  Label
};
